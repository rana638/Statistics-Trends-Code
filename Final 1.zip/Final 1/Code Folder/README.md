# GDP per Capita Analysis - Final Submission
Author: Zafar Iftikhar
Files included: GDP analysis.py, GDP per Capita Report Zafar Iftikhar CalibriStyle.pdf, moments.csv, requirements.txt
